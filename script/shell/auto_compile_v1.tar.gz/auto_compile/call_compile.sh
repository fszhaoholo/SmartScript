#!/bin/bash

# code path
code_path="/home/holo/zhaofx/workspace/code/test/auto_compile/"

if [ ! -d "$code_path" ];then
    echo "The path is not exist, path = $code_path"
    exit 1
fi

# paramter instruction: module_name git_branch_name build_env_name git_clone_url cmake_on_off
compile_sh_paramter_list=(
    'holo_base,parking_dev_v2,build_parking,ssh://git@out.holomatic.ai:5005/base/holo_base.git,on'
    'holo_map,parking_dev_v2,build_parking,ssh://git@out.holomatic.ai:5005/map/holo_map.git,on'
    # 'holo_sensors,parking_dev_v2,build_parking,ssh://git@out.holomatic.ai:5005/vs/holo_sensors.git,on'
    # 'holo_vis,parking_dev_v2,build_parking,ssh://git@out.holomatic.ai:5005/holo/holo_vis.git,on'
    'holo_cmw,parking_dev_v2,build_parking,ssh://git@out.holomatic.ai:5005/cmw/holo_cmw.git,on'
    # 'holo_simulator,parking_dev_v2,build_parking,ssh://git@out.holomatic.ai:5005/sim/holo_simulator.git,on'
)

for i in "${compile_sh_paramter_list[@]}" ;
do
    array=(${i//,/ })
    module=${array[0]}
    branch_name=${array[1]}
    build_env=${array[2]}
    clone_url=${array[3]}
    cmake_on_off=${array[4]}
    ./clone_code.sh ${code_path} ${module} ${clone_url}
    ./compile.sh ${code_path} ${module} ${branch_name} ${build_env} ${cmake_on_off}
done

echo "Done"