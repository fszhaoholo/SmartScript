there are two shell script.
get_map_data.sh 
	should be used in the computer which had the latest map data, such as rootserver blockserver and so on.
install_map_data.sh
	should be used in the target computer which you want to update map data.


note:
	you should use the two shell script follow the steps:
	1.put the two script in a USB.
	2.put the USB into the computer which had the latest map data.
	3.execute the 'get_map_data.sh'.
	4.put the USB into the target computer which you want.
	5.execute the 'install_map_data.sh'
